interface Employee {
  public float calcSalary(int days);
}
class Crew implements Team {
  public void partOf() {
    System.out.print("faz parte do crew");
  }
}
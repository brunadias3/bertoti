interface Team {
  void partOf();
}